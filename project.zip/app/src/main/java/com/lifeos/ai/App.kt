package com.lifeos.ai

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.lifeos.ai.notify.CheckWorker
import com.lifeos.ai.notify.Notifier
import java.util.concurrent.TimeUnit

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannel(this)
        val req = PeriodicWorkRequestBuilder<CheckWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("lifeos_check", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}
