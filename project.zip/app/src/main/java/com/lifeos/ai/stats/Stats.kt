package com.lifeos.ai.stats

import com.lifeos.ai.data.SessionEntity
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.roundToInt

data class AppStat(
    val pkg: String,
    val totalMs: Long,
    val launches: Int,
    val sessions: Int,
    val firstMs: Long,
    val lastMs: Long
) {
    val avgMs: Long get() = if (sessions > 0) totalMs / sessions else 0L
}

data class DayStat(val dayStart: Long, val totalMs: Long, val launches: Int, val sessions: Int) {
    val avgMs: Long get() = if (sessions > 0) totalMs / sessions else 0L
}

data class PeriodStats(
    val from: Long,
    val to: Long,
    val totalMs: Long,
    val launches: Int,
    val returns: Int,
    val sessions: Int,
    val apps: List<AppStat>,
    val hourly: List<Long>,
    val daily: List<DayStat>
) {
    val topByTime: AppStat? get() = apps.firstOrNull()
    val topByLaunches: AppStat? get() = apps.filter { it.launches > 0 }.maxByOrNull { it.launches }
    val daysWithData: Int get() = daily.count { it.totalMs > 0 }
    val avgSessionMs: Long get() = if (sessions > 0) totalMs / sessions else 0L
}

object Stats {
    val zone: ZoneId get() = ZoneId.systemDefault()

    fun dayStart(ms: Long): Long =
        Instant.ofEpochMilli(ms).atZone(zone).toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()

    fun addDays(ms: Long, n: Long): Long =
        Instant.ofEpochMilli(ms).atZone(zone).plusDays(n).toInstant().toEpochMilli()

    fun localDateStart(d: LocalDate): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

    private class Acc {
        var total = 0L
        var launches = 0
        var sessions = 0
        var first = Long.MAX_VALUE
        var last = 0L
    }

    /** Считает статистику по сессиям, обрезая их по границам [from, to). */
    fun compute(sessions: List<SessionEntity>, from: Long, to: Long): PeriodStats {
        val apps = HashMap<String, Acc>()
        val hourly = LongArray(24)
        val dayMap = HashMap<Long, LongArray>()
        var total = 0L
        var launches = 0
        var returns = 0
        var count = 0

        for (s in sessions) {
            val a = maxOf(s.startMs, from)
            val b = minOf(s.endMs, to)
            if (b <= a) continue
            val acc = apps.getOrPut(s.pkg) { Acc() }
            acc.total += b - a
            total += b - a
            acc.first = minOf(acc.first, a)
            acc.last = maxOf(acc.last, b)

            if (s.startMs >= from && s.startMs < to) {
                acc.sessions++
                count++
                val arr = dayMap.getOrPut(dayStart(s.startMs)) { LongArray(3) }
                arr[2]++
                if (s.kind == 0) {
                    acc.launches++
                    launches++
                    arr[1]++
                } else {
                    returns++
                }
            }

            var t = a
            while (t < b) {
                val z = Instant.ofEpochMilli(t).atZone(zone)
                val nextHour = z.truncatedTo(ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli()
                val end = minOf(b, nextHour)
                hourly[z.hour] += end - t
                val ds = z.toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
                dayMap.getOrPut(ds) { LongArray(3) }[0] += end - t
                t = end
            }
        }

        val days = ArrayList<DayStat>()
        var d = dayStart(from)
        var guard = 0
        while (d < to && guard++ < 4000) {
            val arr = dayMap[d]
            days.add(DayStat(d, arr?.get(0) ?: 0L, (arr?.get(1) ?: 0L).toInt(), (arr?.get(2) ?: 0L).toInt()))
            d = addDays(d, 1)
        }

        val list = apps.map { (pkg, x) ->
            AppStat(pkg, x.total, x.launches, x.sessions, if (x.first == Long.MAX_VALUE) 0L else x.first, x.last)
        }.sortedByDescending { it.totalMs }

        return PeriodStats(from, to, total, launches, returns, count, list, hourly.toList(), days)
    }
}

object Fmt {
    private val ru: Locale get() = Locale.forLanguageTag("ru")

    fun dur(ms: Long): String {
        val s = ms / 1000
        return when {
            s <= 0 -> "0 мин"
            s < 60 -> "$s сек"
            s < 3600 -> "${s / 60} мин"
            else -> {
                val h = s / 3600
                val m = (s % 3600) / 60
                if (m == 0L) "$h ч" else "$h ч $m мин"
            }
        }
    }

    fun time(ms: Long): String =
        DateTimeFormatter.ofPattern("HH:mm").format(Instant.ofEpochMilli(ms).atZone(Stats.zone))

    fun date(ms: Long): String =
        DateTimeFormatter.ofPattern("d MMMM, EEE", ru).format(Instant.ofEpochMilli(ms).atZone(Stats.zone))

    fun dateTime(ms: Long): String =
        Instant.ofEpochMilli(ms).atZone(Stats.zone).toOffsetDateTime().toString()

    fun minutes(ms: Long): Float = ms / 60000f

    /** Процент изменения. null — если сравнивать не с чем. */
    fun pct(cur: Long, prev: Long): Int? = if (prev <= 0L) null else ((cur - prev) * 100.0 / prev).roundToInt()

    fun signed(p: Int): String = if (p > 0) "+$p%" else "$p%"

    fun hourLabels(): List<String> = List(24) { if (it % 6 == 0) "%02d".format(it) else "" }

    fun dayLabels(days: List<DayStat>, weekdays: Boolean): List<String> = days.mapIndexed { i, d ->
        val z = Instant.ofEpochMilli(d.dayStart).atZone(Stats.zone)
        if (weekdays) z.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, ru)
        else if (i % 5 == 0) z.dayOfMonth.toString() else ""
    }
}
