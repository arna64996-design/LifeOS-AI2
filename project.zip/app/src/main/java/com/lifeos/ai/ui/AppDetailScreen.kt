package com.lifeos.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.usage.Apps

@Composable
fun AppDetailScreen(vm: MainViewModel, pkg: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val detail by produceState<AppDetail?>(null, pkg) { value = vm.appDetail(pkg) }
    var limit by remember { mutableIntStateOf(prefs.limits()[pkg] ?: 0) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад") }
                AppIcon(pkg, 44.dp)
                Spacer(Modifier.width(12.dp))
                Text(Apps.label(ctx, pkg), fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2)
            }
        }
        val d = detail
        if (d == null) {
            item { LoadingCard() }
        } else {
            item {
                LCard {
                    CardTitle("Время использования")
                    Spacer(Modifier.height(8.dp))
                    listOf("Сегодня" to d.today, "7 дней" to d.week, "30 дней" to d.month, "Вся история" to d.all).forEach { (name, s) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(name)
                                Dim("${s.launches} запусков · ${s.sessions} сессий · сред. ${Fmt.dur(s.avgSessionMs)}", size = 12)
                            }
                            Text(Fmt.dur(s.totalMs), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            val a = d.today.apps.firstOrNull()
            item {
                LCard {
                    CardTitle("Сегодня")
                    Spacer(Modifier.height(6.dp))
                    if (a == null) {
                        Dim("Сегодня использование не обнаружено.", size = 14)
                    } else {
                        Text("Первое обнаруженное использование: ${Fmt.time(a.firstMs)}")
                        Text("Последнее: ${Fmt.time(a.lastMs)}")
                    }
                }
            }
            val days = d.month.daily.takeLast(14)
            if (d.month.daysWithData >= 2) {
                item {
                    LCard {
                        CardTitle("Последние 14 дней")
                        Dim("Минуты в день")
                        Spacer(Modifier.height(12.dp))
                        BarChart(days.map { Fmt.minutes(it.totalMs) }, Fmt.dayLabels(days, false))
                    }
                }
                item {
                    LCard {
                        CardTitle("Активность по часам")
                        Dim("Сумма за 7 дней")
                        Spacer(Modifier.height(12.dp))
                        BarChart(d.week.hourly.map { Fmt.minutes(it) }, Fmt.hourLabels())
                    }
                }
            } else {
                item { MessageCard("Недостаточно истории", "Графики появятся, когда накопится больше одного дня данных по этому приложению.") }
            }
        }
        item {
            LCard {
                CardTitle("Дневной лимит")
                Dim("Уведомление придёт, когда время за день достигнет лимита (если включены уведомления).", size = 12)
                Spacer(Modifier.height(8.dp))
                Stepper(
                    "Лимит", if (limit == 0) "не задан" else "$limit мин",
                    onMinus = { limit = (limit - 15).coerceAtLeast(0); prefs.setLimit(pkg, limit) },
                    onPlus = { limit += 15; prefs.setLimit(pkg, limit) }
                )
            }
        }
    }
}
