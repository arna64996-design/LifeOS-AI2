package com.lifeos.ai.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.lifeos.ai.usage.Apps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun LCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val base = modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m.padding(16.dp), content = content)
}

@Composable
fun Title(text: String) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun CardTitle(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Dim(text: String, modifier: Modifier = Modifier, size: Int = 13) {
    Text(text, modifier = modifier, color = TextDim, fontSize = size.sp)
}

@Composable
fun Tag(text: String, color: Color = Cyan) {
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun ChangeText(pct: Int?, suffix: String) {
    if (pct == null) {
        Dim("Нет данных для сравнения")
    } else {
        val up = pct > 0
        Row(verticalAlignment = Alignment.CenterVertically) {
            Tag((if (up) "▲ " else if (pct < 0) "▼ " else "") + "${if (pct > 0) "+" else ""}$pct%", if (up) Danger else Good)
            Spacer(Modifier.width(8.dp))
            Dim(suffix)
        }
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, sub: String? = null) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(CardBg).padding(16.dp)) {
        Dim(label)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (sub != null) Dim(sub, size = 11)
    }
}

@Composable
fun BarChart(values: List<Float>, labels: List<String>, modifier: Modifier = Modifier, height: Dp = 120.dp) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(values) {
        anim.snapTo(0f)
        anim.animateTo(1f, tween(600))
    }
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(height)) {
            val n = values.size
            if (n == 0) return@Canvas
            val maxV = (values.maxOrNull() ?: 0f).coerceAtLeast(0.0001f)
            val slot = size.width / n
            val bw = slot * 0.62f
            values.forEachIndexed { i, v ->
                val h = (size.height * (v / maxV) * anim.value).coerceAtLeast(3f)
                val top = size.height - h
                val brush = if (v <= 0f) SolidColor(CardBg2)
                else Brush.verticalGradient(listOf(Cyan, Violet), startY = top, endY = size.height)
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(i * slot + (slot - bw) / 2f, top),
                    size = Size(bw, h),
                    cornerRadius = CornerRadius(bw / 4f, bw / 4f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            labels.forEach {
                Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = TextDim, maxLines = 1, softWrap = false)
            }
        }
    }
}

object IconCache {
    private val map = HashMap<String, ImageBitmap?>()

    @Synchronized
    fun get(ctx: Context, pkg: String): ImageBitmap? {
        if (map.containsKey(pkg)) return map[pkg]
        val b = try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
        map[pkg] = b
        return b
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current.applicationContext
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.Default) { IconCache.get(ctx, pkg) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(size / 4)))
    } else {
        Box(Modifier.size(size).clip(CircleShape).background(CardBg2), contentAlignment = Alignment.Center) {
            Text(Apps.label(ctx, pkg).take(1).uppercase(), color = TextDim)
        }
    }
}

@Composable
fun AppRow(pkg: String, title: String, sub: String, value: String, fraction: Float, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(pkg, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row {
                Text(title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Text(value, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(CardBg2)) {
                Box(
                    Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight()
                        .background(Brush.horizontalGradient(listOf(Cyan, Violet)))
                )
            }
            Spacer(Modifier.height(4.dp))
            Dim(sub, size = 12)
        }
    }
}

@Composable
fun MessageCard(title: String, text: String, button: String? = null, onClick: (() -> Unit)? = null) {
    LCard {
        CardTitle(title)
        Spacer(Modifier.height(6.dp))
        Dim(text, size = 14)
        if (button != null && onClick != null) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick) { Text(button) }
        }
    }
}

@Composable
fun LoadingCard() {
    LCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Cyan)
            Spacer(Modifier.width(12.dp))
            Text("Загружаю данные…")
        }
    }
}

@Composable
fun Stepper(label: String, valueText: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedButton(onClick = onMinus, modifier = Modifier.size(40.dp), contentPadding = PaddingValues(0.dp)) { Text("−") }
        Text(valueText, Modifier.widthIn(min = 80.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
        OutlinedButton(onClick = onPlus, modifier = Modifier.size(40.dp), contentPadding = PaddingValues(0.dp)) { Text("+") }
    }
}

@Composable
fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Dim(sub, size = 12)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

fun toast(ctx: Context, text: String) {
    Toast.makeText(ctx, text, Toast.LENGTH_LONG).show()
}

fun openUsageAccess(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            toast(ctx, "Не удалось открыть настройки. Откройте: Настройки → Приложения → Специальный доступ → Доступ к данным об использовании.")
        }
    }
}

@Composable
fun PermissionGate() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        androidx.compose.material3.Icon(Icons.Default.Info, contentDescription = null, tint = Cyan, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Нужен доступ к статистике", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "LifeOS AI показывает, какие приложения вы используете и сколько времени. Данные берутся из системной статистики Android и остаются на телефоне.",
            color = TextDim, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Нажмите кнопку, найдите в списке «LifeOS AI» и включите переключатель. Затем вернитесь в приложение.",
            color = TextDim, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = { openUsageAccess(ctx) }) { Text("Открыть настройки доступа") }
    }
}
