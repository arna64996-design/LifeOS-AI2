package com.lifeos.ai.notify

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.lifeos.ai.data.AppDb
import com.lifeos.ai.data.NotifEntity
import com.lifeos.ai.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Сохраняет ТОЛЬКО приложение-источник и время уведомления.
 * Текст, заголовок и содержимое уведомлений не читаются и не сохраняются.
 */
class NotifListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs(this).collectNotifs) return
        if (sbn.packageName == packageName || sbn.isOngoing) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val pkg = sbn.packageName
        val t = sbn.postTime
        scope.launch {
            AppDb.get(applicationContext).dao().insertNotif(NotifEntity(pkg = pkg, timeMs = t))
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
