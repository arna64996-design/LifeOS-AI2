package com.lifeos.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF14161B)
val CardBg = Color(0xFF1E2128)
val CardBg2 = Color(0xFF2A2E38)
val Cyan = Color(0xFF4FC3F7)
val Violet = Color(0xFF8B7CF6)
val TextMain = Color(0xFFECEFF4)
val TextDim = Color(0xFF9AA3B2)
val Danger = Color(0xFFFF8A65)
val Good = Color(0xFF5EE0A0)

@Composable
fun LifeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            onPrimary = Color(0xFF00212E),
            secondary = Violet,
            background = Bg,
            onBackground = TextMain,
            surface = CardBg,
            onSurface = TextMain,
            surfaceVariant = CardBg2,
            onSurfaceVariant = TextDim
        ),
        content = content
    )
}
