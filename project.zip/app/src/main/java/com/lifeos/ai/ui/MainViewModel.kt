package com.lifeos.ai.ui

import android.app.Application
import android.net.Uri
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lifeos.ai.ai.AiService
import com.lifeos.ai.ai.ChatMsg
import com.lifeos.ai.ai.LocalInsights
import com.lifeos.ai.data.AppDb
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.data.SessionEntity
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.stats.PeriodStats
import com.lifeos.ai.stats.Stats
import com.lifeos.ai.usage.Apps
import com.lifeos.ai.usage.UsageCollector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.SocketTimeoutException
import java.net.UnknownHostException

data class UiState(
    val loading: Boolean = true,
    val hasPermission: Boolean = false,
    val error: String? = null,
    val today: PeriodStats? = null,
    val yesterday: PeriodStats? = null,
    val last7: PeriodStats? = null,
    val historyDays: Int = 0,
    val lastSync: Long = 0L
)

data class StatsResult(val period: Int, val cur: PeriodStats, val prev: PeriodStats?)
data class JFilter(val mode: Int = 0, val dateMs: Long = 0L, val pkg: String? = null)
data class JournalState(val items: List<SessionEntity> = emptyList(), val pkgs: List<String> = emptyList())
data class AppDetail(val today: PeriodStats, val week: PeriodStats, val month: PeriodStats, val all: PeriodStats)
data class NotifStats(
    val active: Boolean = false,
    val today: Int = 0,
    val yesterday: Int = 0,
    val byApp: List<Pair<String, Int>> = emptyList(),
    val daily: List<Int> = emptyList()
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx: Application get() = getApplication()
    private val dao = AppDb.get(app).dao()
    private val prefs = Prefs(app)

    private val _ui = MutableStateFlow(UiState(hasPermission = UsageCollector.hasPermission(app)))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _period = MutableStateFlow(0)
    val period: StateFlow<Int> = _period.asStateFlow()
    private val _stats = MutableStateFlow<StatsResult?>(null)
    val stats: StateFlow<StatsResult?> = _stats.asStateFlow()

    private val _jf = MutableStateFlow(JFilter())
    val jFilter: StateFlow<JFilter> = _jf.asStateFlow()
    private val _journal = MutableStateFlow(JournalState())
    val journal: StateFlow<JournalState> = _journal.asStateFlow()

    private val _notifs = MutableStateFlow(NotifStats())
    val notifs: StateFlow<NotifStats> = _notifs.asStateFlow()

    private val _insights = MutableStateFlow<List<String>>(emptyList())
    val insights: StateFlow<List<String>> = _insights.asStateFlow()

    private val _chat = MutableStateFlow<List<ChatMsg>>(emptyList())
    val chat: StateFlow<List<ChatMsg>> = _chat.asStateFlow()
    private val _aiBusy = MutableStateFlow(false)
    val aiBusy: StateFlow<Boolean> = _aiBusy.asStateFlow()
    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    @Volatile
    private var busy = false

    fun refresh() {
        if (busy) return
        busy = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val perm = UsageCollector.hasPermission(appCtx)
                if (!perm) {
                    _ui.value = UiState(loading = false, hasPermission = false)
                    return@launch
                }
                _ui.update { it.copy(loading = true, hasPermission = true, error = null) }
                val r = UsageCollector(appCtx).sync()
                r.onFailure { e ->
                    _ui.update { it.copy(error = "Не удалось получить статистику: ${e.message ?: e.javaClass.simpleName}") }
                }
                loadHome()
                loadStats()
                loadJournal()
                loadNotifs()
                _ui.update { it.copy(loading = false) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, error = "Ошибка: ${e.message ?: e.javaClass.simpleName}") }
            } finally {
                busy = false
            }
        }
    }

    private suspend fun loadHome() {
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val all = dao.sessions(Stats.addDays(ds, -13), de)
        val today = Stats.compute(all, ds, de)
        val yest = Stats.compute(all, Stats.addDays(ds, -1), Stats.addDays(now, -1))
        val last7 = Stats.compute(all, Stats.addDays(ds, -6), de)
        val prev7 = Stats.compute(all, Stats.addDays(ds, -13), Stats.addDays(ds, -6))
        val first = dao.firstStart()
        val days = if (first == null) 0 else ((now - Stats.dayStart(first)) / 86_400_000L).toInt() + 1
        _ui.update { it.copy(today = today, yesterday = yest, last7 = last7, historyDays = days, lastSync = prefs.lastSync) }
        _insights.value = LocalInsights.generate(appCtx, today, last7, prev7, days)
    }

    // ---------- Статистика ----------
    fun setPeriod(p: Int) {
        _period.value = p
        viewModelScope.launch(Dispatchers.Default) { loadStats() }
    }

    private suspend fun loadStats() {
        val p = _period.value
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val to = Stats.addDays(ds, 1)
        val from = when (p) {
            0 -> ds
            1 -> Stats.addDays(ds, -6)
            2 -> Stats.addDays(ds, -29)
            else -> dao.firstStart()?.let { Stats.dayStart(it) } ?: ds
        }
        val prevRange: Pair<Long, Long>? = when (p) {
            0 -> Stats.addDays(ds, -1) to Stats.addDays(now, -1)
            1 -> Stats.addDays(from, -7) to from
            2 -> Stats.addDays(from, -30) to from
            else -> null
        }
        val sess = dao.sessions(prevRange?.first ?: from, to)
        _stats.value = StatsResult(p, Stats.compute(sess, from, to), prevRange?.let { Stats.compute(sess, it.first, it.second) })
    }

    // ---------- Журнал ----------
    fun setJournalMode(mode: Int) {
        _jf.update { it.copy(mode = mode) }
        viewModelScope.launch(Dispatchers.Default) { loadJournal() }
    }

    fun setJournalDate(dayStartMs: Long) {
        _jf.update { it.copy(mode = 4, dateMs = dayStartMs) }
        viewModelScope.launch(Dispatchers.Default) { loadJournal() }
    }

    fun setJournalApp(pkg: String?) {
        _jf.update { it.copy(pkg = pkg) }
        viewModelScope.launch(Dispatchers.Default) { loadJournal() }
    }

    private suspend fun loadJournal() {
        val f = _jf.value
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val (from, to) = when (f.mode) {
            0 -> ds to de
            1 -> Stats.addDays(ds, -1) to ds
            2 -> Stats.addDays(ds, -6) to de
            3 -> Stats.addDays(ds, -29) to de
            else -> {
                val d = if (f.dateMs == 0L) ds else f.dateMs
                d to Stats.addDays(d, 1)
            }
        }
        val all = dao.sessions(from, to)
        val pkgs = all.map { it.pkg }.distinct().sortedBy { Apps.label(appCtx, it).lowercase() }
        val items = all.filter { f.pkg == null || it.pkg == f.pkg }.sortedByDescending { it.startMs }
        _journal.value = JournalState(items, pkgs)
    }

    // ---------- Приложение ----------
    suspend fun appDetail(pkg: String): AppDetail = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val first = dao.firstStart()?.let { Stats.dayStart(it) } ?: ds
        val list = dao.sessions(first, de).filter { it.pkg == pkg }
        AppDetail(
            Stats.compute(list, ds, de),
            Stats.compute(list, Stats.addDays(ds, -6), de),
            Stats.compute(list, Stats.addDays(ds, -29), de),
            Stats.compute(list, first, de)
        )
    }

    // ---------- Уведомления других приложений ----------
    private suspend fun loadNotifs() {
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val list = dao.notifs(Stats.addDays(ds, -6), de)
        val listener = NotificationManagerCompat.getEnabledListenerPackages(appCtx).contains(appCtx.packageName)
        val days = (0..6).map { i ->
            val s = Stats.addDays(ds, (i - 6).toLong())
            val e = Stats.addDays(s, 1)
            list.count { it.timeMs >= s && it.timeMs < e }
        }
        val byApp = list.filter { it.timeMs >= ds }.groupBy { it.pkg }
            .map { it.key to it.value.size }.sortedByDescending { it.second }
        _notifs.value = NotifStats(listener && prefs.collectNotifs, days[6], days[5], byApp, days)
    }

    fun deleteNotifs() {
        viewModelScope.launch(Dispatchers.Default) {
            dao.clearNotifs()
            loadNotifs()
        }
    }

    // ---------- Данные ----------
    suspend fun exportCsv(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val list = dao.sessions(0L, Long.MAX_VALUE)
            val out = appCtx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Не удалось открыть файл")
            out.bufferedWriter().use { w ->
                w.write("package,app,start,end,duration_sec,kind,confidence\n")
                for (s in list) {
                    val name = Apps.label(appCtx, s.pkg).replace("\"", "\"\"")
                    val kind = if (s.kind == 0) "launch" else "return"
                    val conf = if (s.confidence == 2) "high" else "estimated"
                    w.write("${s.pkg},\"$name\",${Fmt.dateTime(s.startMs)},${Fmt.dateTime(s.endMs)},${(s.endMs - s.startMs) / 1000},$kind,$conf\n")
                }
            }
            list.size
        }
    }

    /** Удаляет всё и не загружает старые данные заново. */
    fun deleteHistory() {
        viewModelScope.launch(Dispatchers.Default) {
            dao.clearSessions()
            dao.clearNotifs()
            prefs.lastSync = System.currentTimeMillis()
            loadHome(); loadStats(); loadJournal(); loadNotifs()
        }
    }

    /** Очищает и заново собирает то, что ещё хранит система (около 7 дней). */
    fun resetStats() {
        viewModelScope.launch(Dispatchers.Default) {
            dao.clearSessions()
            prefs.lastSync = 0L
            refresh()
        }
    }

    // ---------- ИИ ----------
    fun askAi(question: String) {
        if (_aiBusy.value || question.isBlank()) return
        _chat.update { it + ChatMsg("user", question.trim()) }
        _aiBusy.value = true
        _aiError.value = null
        viewModelScope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { AiService.ask(appCtx, _chat.value) }
                _chat.update { it + ChatMsg("assistant", answer) }
            } catch (e: UnknownHostException) {
                _aiError.value = "Нет подключения к интернету."
            } catch (e: SocketTimeoutException) {
                _aiError.value = "Сервер ИИ не ответил вовремя. Попробуйте ещё раз."
            } catch (e: Exception) {
                _aiError.value = e.message ?: "Не удалось получить ответ."
            } finally {
                _aiBusy.value = false
            }
        }
    }

    fun clearChat() {
        _chat.value = emptyList()
        _aiError.value = null
    }
}
