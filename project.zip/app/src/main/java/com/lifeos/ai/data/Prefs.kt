package com.lifeos.ai.data

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("lifeos", Context.MODE_PRIVATE)

    private inner class B(val key: String, val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(key, value).apply()
        }
    }

    private inner class I(val key: String, val def: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(key, value).apply()
        }
    }

    private inner class L(val key: String, val def: Long) : ReadWriteProperty<Any?, Long> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Long = sp.getLong(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
            sp.edit().putLong(key, value).apply()
        }
    }

    private inner class S(val key: String, val def: String) : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(key, def) ?: def
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(key, value).apply()
        }
    }

    var notifyEnabled by B("notify_enabled", false)
    var notifyHour by I("notify_hour", 21)
    var alertDaily by B("alert_daily", true)
    var dailyLimitMin by I("daily_limit_min", 240)
    var alertAppLimits by B("alert_app_limits", true)
    var appLimitsRaw by S("app_limits", "")
    var alertLaunches by B("alert_launches", true)
    var launchesLimit by I("launches_limit", 18)
    var alertVsYesterday by B("alert_vs_yesterday", true)
    var alertWeekGrowth by B("alert_week_growth", true)

    var collectNotifs by B("collect_notifs", false)

    var aiProvider by S("ai_provider", "openai")
    var aiUrl by S("ai_url", "https://api.openai.com/v1")
    var aiModel by S("ai_model", "gpt-4o-mini")
    var aiKey by S("ai_key", "")
    var aiConsent by B("ai_consent", false)

    var lastSync by L("last_sync", 0L)

    fun limits(): Map<String, Int> = appLimitsRaw.split(";").mapNotNull {
        val p = it.split("=")
        if (p.size == 2) p[1].toIntOrNull()?.let { m -> p[0] to m } else null
    }.toMap()

    fun setLimit(pkg: String, min: Int) {
        val m = limits().toMutableMap()
        if (min <= 0) m.remove(pkg) else m[pkg] = min
        appLimitsRaw = m.entries.joinToString(";") { "${it.key}=${it.value}" }
    }

    fun wasSent(key: String): Boolean = sp.getBoolean("sent_$key", false)
    fun markSent(key: String) { sp.edit().putBoolean("sent_$key", true).apply() }
    fun dayCount(day: String): Int = sp.getInt("cnt_$day", 0)
    fun incDayCount(day: String) { sp.edit().putInt("cnt_$day", dayCount(day) + 1).apply() }
}
