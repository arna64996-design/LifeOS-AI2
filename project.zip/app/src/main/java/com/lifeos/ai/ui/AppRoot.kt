package com.lifeos.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by rememberSaveable { mutableStateOf<String?>(null) }
    val items = listOf(
        "Главная" to Icons.Default.Home,
        "Статистика" to Icons.Default.Info,
        "Журнал" to Icons.Default.List,
        "Помощник" to Icons.Default.Face,
        "Настройки" to Icons.Default.Settings
    )

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = CardBg) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; detail = null },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00212E),
                            indicatorColor = Cyan,
                            selectedTextColor = Cyan,
                            unselectedIconColor = TextDim,
                            unselectedTextColor = TextDim
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val d = detail
            if (d != null) {
                BackHandler { detail = null }
                AppDetailScreen(vm, d) { detail = null }
            } else {
                when (tab) {
                    0 -> HomeScreen(vm) { detail = it }
                    1 -> StatsScreen(vm) { detail = it }
                    2 -> JournalScreen(vm) { detail = it }
                    3 -> AiScreen(vm) { tab = 4 }
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}
