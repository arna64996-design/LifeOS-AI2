package com.lifeos.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.usage.Apps

@Composable
fun StatsScreen(vm: MainViewModel, onOpenApp: (String) -> Unit) {
    val ui by vm.ui.collectAsState()
    val period by vm.period.collectAsState()
    val res by vm.stats.collectAsState()
    val notif by vm.notifs.collectAsState()
    val ctx = LocalContext.current
    if (!ui.hasPermission) {
        PermissionGate()
        return
    }
    val titles = listOf("Сегодня", "Неделя", "Месяц", "Вся история")
    val compareText = listOf("к этому же времени вчера", "к предыдущим 7 дням", "к предыдущим 30 дням", "")

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Title("Статистика") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                titles.forEachIndexed { i, t ->
                    FilterChip(selected = period == i, onClick = { vm.setPeriod(i) }, label = { Text(t) })
                }
            }
        }
        val r = res
        if (r == null) {
            item { LoadingCard() }
        } else {
            val cur = r.cur
            val prev = r.prev
            if (cur.sessions == 0) {
                item {
                    MessageCard(
                        "Недостаточно данных",
                        "За выбранный период нет событий использования. Android хранит их около недели, дальше история копится в приложении по мере работы."
                    )
                }
            } else {
                item {
                    LCard {
                        Dim("Общее время")
                        Text(Fmt.dur(cur.totalMs), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        if (prev != null) ChangeText(Fmt.pct(cur.totalMs, prev.totalMs), compareText[period])
                        Spacer(Modifier.height(10.dp))
                        Dim("Запусков: ${cur.launches} · возвращений: ${cur.returns} · сессий: ${cur.sessions}")
                        Dim("Средняя сессия: ${Fmt.dur(cur.avgSessionMs)}")
                    }
                }
                if (period == 0) {
                    item {
                        LCard {
                            CardTitle("Использование по часам")
                            Spacer(Modifier.height(12.dp))
                            BarChart(cur.hourly.map { Fmt.minutes(it) }, Fmt.hourLabels())
                        }
                    }
                } else if (cur.daysWithData < 2) {
                    item {
                        MessageCard(
                            "Недостаточно истории для графиков",
                            "Графики по дням появятся, когда накопится хотя бы два дня данных. Сейчас дней с данными: ${cur.daysWithData}."
                        )
                    }
                } else {
                    val days = cur.daily.takeLast(31)
                    val labels = Fmt.dayLabels(days, period == 1)
                    item {
                        LCard {
                            CardTitle("Экранное время по дням")
                            Dim("Минуты в день")
                            Spacer(Modifier.height(12.dp))
                            BarChart(days.map { Fmt.minutes(it.totalMs) }, labels)
                        }
                    }
                    item {
                        LCard {
                            CardTitle("Изменение количества запусков")
                            Dim("Обнаруженные запуски по дням")
                            Spacer(Modifier.height(12.dp))
                            BarChart(days.map { it.launches.toFloat() }, labels)
                        }
                    }
                    item {
                        LCard {
                            CardTitle("Средняя длительность сессии")
                            Dim("Минуты, по дням")
                            Spacer(Modifier.height(12.dp))
                            BarChart(days.map { Fmt.minutes(it.avgMs) }, labels)
                        }
                    }
                }
                item {
                    LCard {
                        CardTitle("Сравнение приложений")
                        Spacer(Modifier.height(4.dp))
                        val max = cur.apps.firstOrNull()?.totalMs?.coerceAtLeast(1L) ?: 1L
                        cur.apps.take(15).forEach { a ->
                            val before = prev?.apps?.firstOrNull { it.pkg == a.pkg }?.totalMs
                            val delta = if (before != null) Fmt.pct(a.totalMs, before) else null
                            val sub = "${a.launches} запусков · ${a.sessions} сессий · сред. ${Fmt.dur(a.avgMs)}" +
                                (if (delta != null) " · ${Fmt.signed(delta)}" else "")
                            AppRow(a.pkg, Apps.label(ctx, a.pkg), sub, Fmt.dur(a.totalMs), a.totalMs.toFloat() / max) { onOpenApp(a.pkg) }
                        }
                    }
                }
            }
        }
        item {
            LCard {
                CardTitle("Уведомления от других приложений")
                Spacer(Modifier.height(6.dp))
                if (!notif.active) {
                    Dim("Анализ выключен. Его можно включить добровольно в Настройках — сохраняются только приложение и время уведомления, без текста.", size = 14)
                } else {
                    Text("Сегодня: ${notif.today} · вчера: ${notif.yesterday}")
                    Spacer(Modifier.height(8.dp))
                    BarChart(notif.daily.map { it.toFloat() }, List(notif.daily.size) { "" }, height = 70.dp)
                    Dim("За 7 дней")
                    Spacer(Modifier.height(8.dp))
                    if (notif.byApp.isEmpty()) Dim("Сегодня уведомлений пока не было.")
                    notif.byApp.take(6).forEach { (pkg, n) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text(Apps.label(ctx, pkg), Modifier.weight(1f), maxLines = 1)
                            Text("$n", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}
