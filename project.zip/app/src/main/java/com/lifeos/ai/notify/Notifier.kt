package com.lifeos.ai.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.lifeos.ai.MainActivity
import com.lifeos.ai.R

object Notifier {
    const val CHANNEL = "lifeos_alerts"

    fun createChannel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, "Подсказки LifeOS", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "Лимиты и наблюдения о том, как вы используете смартфон"
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    fun send(ctx: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
            // нет разрешения — молча пропускаем
        }
    }
}
