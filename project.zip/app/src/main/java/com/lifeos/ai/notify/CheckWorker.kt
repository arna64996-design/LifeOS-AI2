package com.lifeos.ai.notify

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.lifeos.ai.data.AppDb
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.stats.Stats
import com.lifeos.ai.usage.Apps
import com.lifeos.ai.usage.UsageCollector
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.IsoFields

class CheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        if (!UsageCollector.hasPermission(c)) return Result.success()
        UsageCollector(c).sync()
        if (Prefs(c).notifyEnabled) Alerts.evaluate(c)
        return Result.success()
    }
}

object Alerts {
    private const val MAX_PER_DAY = 5

    suspend fun evaluate(ctx: Context) {
        val prefs = Prefs(ctx)
        val dao = AppDb.get(ctx).dao()
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val dayKey = LocalDate.now().toString()
        val all = dao.sessions(Stats.addDays(ds, -13), de)
        val today = Stats.compute(all, ds, de)

        fun once(key: String, title: String, text: String) {
            if (prefs.wasSent(key)) return
            if (prefs.dayCount(dayKey) >= MAX_PER_DAY) return
            prefs.markSent(key)
            prefs.incDayCount(dayKey)
            Notifier.send(ctx, key.hashCode(), title, text)
        }

        if (prefs.alertDaily && prefs.dailyLimitMin > 0 &&
            today.totalMs >= prefs.dailyLimitMin * 60_000L
        ) {
            once("$dayKey:daily", "Дневной лимит достигнут",
                "Сегодня ты провёл в телефоне уже ${Fmt.dur(today.totalMs)}.")
        }

        if (prefs.alertAppLimits) {
            for ((pkg, min) in prefs.limits()) {
                val a = today.apps.firstOrNull { it.pkg == pkg } ?: continue
                if (a.totalMs >= min * 60_000L) {
                    once("$dayKey:app:$pkg", "Лимит приложения",
                        "Сегодня ты провёл в ${Apps.label(ctx, pkg)} уже ${Fmt.dur(a.totalMs)}.")
                }
            }
        }

        if (prefs.alertLaunches && prefs.launchesLimit > 0) {
            val a = today.apps.filter { it.launches >= prefs.launchesLimit }.maxByOrNull { it.launches }
            if (a != null) {
                once("$dayKey:launch:${a.pkg}", "Много запусков",
                    "Ты открыл ${Apps.label(ctx, a.pkg)} ${a.launches} раз за день (по обнаруженным запускам).")
            }
        }

        if (ZonedDateTime.now().hour < prefs.notifyHour) return

        if (prefs.alertVsYesterday) {
            val y = Stats.compute(all, Stats.addDays(ds, -1), Stats.addDays(now, -1))
            val pct = Fmt.pct(today.totalMs, y.totalMs)
            if (pct != null && pct >= 20 && today.totalMs - y.totalMs >= 20 * 60_000L) {
                once("$dayKey:vsy", "Активнее, чем вчера",
                    "Сегодня ты используешь телефон активнее, чем вчера: ${Fmt.signed(pct)} к этому же времени.")
            }
        }

        if (prefs.alertWeekGrowth) {
            val w = Stats.compute(all, Stats.addDays(ds, -6), de)
            val p = Stats.compute(all, Stats.addDays(ds, -13), Stats.addDays(ds, -6))
            val week = LocalDate.now().let { "${it.year}-W${it.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR)}" }
            for (a in w.apps) {
                val before = p.apps.firstOrNull { it.pkg == a.pkg }?.totalMs ?: continue
                val pct = Fmt.pct(a.totalMs, before) ?: continue
                if (pct >= 30 && a.totalMs - before >= 30 * 60_000L) {
                    once("$week:growth:${a.pkg}", "Рост за неделю",
                        "За последнюю неделю время в ${Apps.label(ctx, a.pkg)} выросло: ${Fmt.signed(pct)}.")
                    break
                }
            }
        }
    }
}
