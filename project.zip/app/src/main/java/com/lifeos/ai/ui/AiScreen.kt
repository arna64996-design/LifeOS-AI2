package com.lifeos.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifeos.ai.ai.AiService
import com.lifeos.ai.data.Prefs

@Composable
fun AiScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val configured = AiService.configured(prefs)
    val chat by vm.chat.collectAsState()
    val busy by vm.aiBusy.collectAsState()
    val error by vm.aiError.collectAsState()
    val insights by vm.insights.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(chat.size, busy) {
        val n = listState.layoutInfo.totalItemsCount
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Title("ИИ-помощник") }
            item {
                LCard {
                    CardTitle("Локальный анализ (без ИИ)")
                    Dim("Это простые правила по вашей статистике, работают без интернета. Это не нейросеть.", size = 12)
                    Spacer(Modifier.height(8.dp))
                    if (insights.isEmpty()) Dim("Пока нечего анализировать.", size = 14)
                    insights.forEach {
                        Text("• $it", Modifier.padding(vertical = 3.dp))
                    }
                }
            }
            if (!configured) {
                item {
                    MessageCard(
                        "Чат с ИИ не настроен",
                        "Чтобы задавать вопросы языковой модели, укажите провайдера и ключ API и дайте согласие на отправку сводки статистики. Без этого данные никуда не отправляются.",
                        "Открыть настройки ИИ", onOpenSettings
                    )
                }
            } else {
                item {
                    Dim("Модель получает только сводку статистики из приложения и отвечает по ней. Если данных мало, она должна сказать об этом.", size = 12)
                }
            }
            items(chat) { m ->
                val mine = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (mine) Cyan.copy(alpha = 0.2f) else CardBg)
                            .padding(12.dp)
                    ) { Text(m.text) }
                }
            }
            if (busy) item { LoadingCard() }
            val e = error
            if (e != null) item { MessageCard("Не получилось", e) }
        }

        if (configured) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "На что я потратил больше всего времени сегодня?",
                    "Какие приложения стали занимать больше времени?",
                    "В какое время я наиболее активен?",
                    "Как сократить время в самых затратных приложениях?",
                    "Как изменились мои привычки за неделю?"
                ).forEach { q ->
                    AssistChip(onClick = { vm.askAi(q) }, label = { Text(q) })
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Ваш вопрос") }, maxLines = 3
                )
                IconButton(onClick = { vm.askAi(input); input = "" }, enabled = !busy && input.isNotBlank()) {
                    Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Cyan)
                }
            }
        }
    }
}
