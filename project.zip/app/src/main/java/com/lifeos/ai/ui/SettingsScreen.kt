package com.lifeos.ai.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.usage.Apps
import com.lifeos.ai.usage.UsageCollector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    val ui by vm.ui.collectAsState()

    var notifyOn by remember { mutableStateOf(prefs.notifyEnabled) }
    var hour by remember { mutableIntStateOf(prefs.notifyHour) }
    var aDaily by remember { mutableStateOf(prefs.alertDaily) }
    var dailyMin by remember { mutableIntStateOf(prefs.dailyLimitMin) }
    var aApps by remember { mutableStateOf(prefs.alertAppLimits) }
    var aLaunch by remember { mutableStateOf(prefs.alertLaunches) }
    var launchLim by remember { mutableIntStateOf(prefs.launchesLimit) }
    var aYest by remember { mutableStateOf(prefs.alertVsYesterday) }
    var aWeek by remember { mutableStateOf(prefs.alertWeekGrowth) }
    var limits by remember { mutableStateOf(prefs.limits()) }
    var collect by remember { mutableStateOf(prefs.collectNotifs) }
    var provider by remember { mutableStateOf(prefs.aiProvider) }
    var url by remember { mutableStateOf(prefs.aiUrl) }
    var model by remember { mutableStateOf(prefs.aiModel) }
    var key by remember { mutableStateOf(prefs.aiKey) }
    var consent by remember { mutableStateOf(prefs.aiConsent) }
    var showPicker by remember { mutableStateOf(false) }
    var pendingPkg by remember { mutableStateOf<String?>(null) }
    var pendingMin by remember { mutableIntStateOf(60) }
    var confirm by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) toast(ctx, "Без разрешения Android не покажет уведомления LifeOS AI.")
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val r = vm.exportCsv(uri)
            toast(ctx, if (r.isSuccess) "Экспортировано записей: ${r.getOrNull()}" else "Ошибка экспорта: ${r.exceptionOrNull()?.message}")
        }
    }

    val hasUsage = UsageCollector.hasPermission(ctx)
    val listenerOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Title("Настройки") }

        item {
            LCard {
                CardTitle("Доступ к статистике")
                Spacer(Modifier.height(4.dp))
                Dim(if (hasUsage) "Доступ предоставлен." else "Доступ не предоставлен — без него приложение ничего не покажет.", size = 14)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { openUsageAccess(ctx) }) { Text(if (hasUsage) "Открыть системные настройки" else "Предоставить доступ") }
            }
        }

        item {
            LCard {
                CardTitle("Уведомления")
                Spacer(Modifier.height(4.dp))
                SwitchRow("Присылать подсказки", "Не более 5 в день", notifyOn) {
                    notifyOn = it; prefs.notifyEnabled = it
                    if (it && Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (notifyOn) {
                    Stepper("Итоги не раньше", "%02d:00".format(hour),
                        { hour = (hour - 1).coerceAtLeast(0); prefs.notifyHour = hour },
                        { hour = (hour + 1).coerceAtMost(23); prefs.notifyHour = hour })
                    SwitchRow("Общий дневной лимит", null, aDaily) { aDaily = it; prefs.alertDaily = it }
                    if (aDaily) Stepper("Лимит", "${dailyMin / 60} ч ${dailyMin % 60} мин",
                        { dailyMin = (dailyMin - 15).coerceAtLeast(15); prefs.dailyLimitMin = dailyMin },
                        { dailyMin += 15; prefs.dailyLimitMin = dailyMin })
                    SwitchRow("Лимиты выбранных приложений", null, aApps) { aApps = it; prefs.alertAppLimits = it }
                    SwitchRow("Много запусков одного приложения", null, aLaunch) { aLaunch = it; prefs.alertLaunches = it }
                    if (aLaunch) Stepper("Порог запусков", "$launchLim",
                        { launchLim = (launchLim - 1).coerceAtLeast(3); prefs.launchesLimit = launchLim },
                        { launchLim += 1; prefs.launchesLimit = launchLim })
                    SwitchRow("Активнее, чем вчера", null, aYest) { aYest = it; prefs.alertVsYesterday = it }
                    SwitchRow("Рост времени за неделю", null, aWeek) { aWeek = it; prefs.alertWeekGrowth = it }

                    Spacer(Modifier.height(8.dp))
                    Text("Приложения под наблюдением")
                    if (limits.isEmpty()) Dim("Пока не выбрано ни одного. Добавьте приложение и задайте лимит.", size = 12)
                    limits.forEach { (pkg, min) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(pkg, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(Apps.label(ctx, pkg), Modifier.weight(1f), maxLines = 1)
                            Text("$min мин")
                            IconButton(onClick = { prefs.setLimit(pkg, 0); limits = prefs.limits() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Убрать")
                            }
                        }
                    }
                    OutlinedButton(onClick = { showPicker = true }) { Text("Добавить приложение") }
                }
                Spacer(Modifier.height(8.dp))
                Dim(
                    "Как это работает: проверка запускается через WorkManager примерно раз в 30 минут. Android и оболочка HyperOS/MIUI могут откладывать её при экономии заряда, поэтому уведомления приходят приблизительно, а не секунда в секунду. Чтобы они приходили стабильнее: Настройки → Приложения → LifeOS AI → Экономия заряда → «Нет ограничений» и включите автозапуск.",
                    size = 12
                )
            }
        }

        item {
            LCard {
                CardTitle("ИИ-помощник")
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = provider == "openai", onClick = {
                        provider = "openai"; url = "https://api.openai.com/v1"; model = "gpt-4o-mini"
                        prefs.aiProvider = provider; prefs.aiUrl = url; prefs.aiModel = model
                    }, label = { Text("OpenAI-совместимый") })
                    FilterChip(selected = provider == "anthropic", onClick = {
                        provider = "anthropic"; url = "https://api.anthropic.com/v1"; model = "claude-haiku-5-5"
                        prefs.aiProvider = provider; prefs.aiUrl = url; prefs.aiModel = model
                    }, label = { Text("Anthropic") })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(url, { url = it; prefs.aiUrl = it }, Modifier.fillMaxWidth(), label = { Text("Адрес API") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(model, { model = it; prefs.aiModel = it }, Modifier.fillMaxWidth(), label = { Text("Модель") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    key, { key = it.trim(); prefs.aiKey = key }, Modifier.fillMaxWidth(),
                    label = { Text("Ключ API") }, singleLine = true, visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(4.dp))
                SwitchRow("Разрешаю отправлять сводку статистики", "Названия приложений и время использования уходят выбранному провайдеру только когда вы задаёте вопрос в чате", consent) {
                    consent = it; prefs.aiConsent = it
                }
                Dim("Ключ вводите сами: в коде приложения его нет. Он хранится только в памяти этого приложения на телефоне. Любой сервис с совместимым API можно подключить, указав его адрес.", size = 12)
            }
        }

        item {
            LCard {
                CardTitle("Анализ уведомлений")
                Spacer(Modifier.height(4.dp))
                SwitchRow("Считать уведомления", "Сохраняются только приложение-источник и время. Текст не читается.", collect) {
                    collect = it; prefs.collectNotifs = it
                }
                Dim(if (listenerOn) "Системный доступ к уведомлениям выдан." else "Системный доступ к уведомлениям не выдан.", size = 13)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        try {
                            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) {
                            toast(ctx, "Не удалось открыть настройки доступа к уведомлениям.")
                        }
                    }) { Text("Системный доступ") }
                    OutlinedButton(onClick = { confirm = 3 }) { Text("Удалить данные") }
                }
            }
        }

        item {
            LCard {
                CardTitle("Данные")
                Spacer(Modifier.height(4.dp))
                Dim("Всё хранится только на этом телефоне.", size = 13)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { exportLauncher.launch("lifeos_history.csv") }, Modifier.fillMaxWidth()) { Text("Экспорт истории (CSV)") }
                OutlinedButton(onClick = { confirm = 2 }, Modifier.fillMaxWidth()) { Text("Сбросить и собрать статистику заново") }
                OutlinedButton(onClick = { confirm = 1 }, Modifier.fillMaxWidth()) { Text("Удалить всю историю") }
            }
        }

        item {
            LCard {
                CardTitle("О приложении")
                Spacer(Modifier.height(4.dp))
                Text("LifeOS AI, версия $version")
                Spacer(Modifier.height(8.dp))
                Dim(
                    "Конфиденциальность: статистика берётся из системного журнала использования Android и хранится локально. Ничего не отправляется на сервер без вашего согласия: единственная отправка — сводка для чата с ИИ, и только если вы включили её выше. Скрытого сбора нет. Приложение не читает содержимое других приложений, не записывает нажатия и не использует службу специальных возможностей.",
                    size = 12
                )
                Spacer(Modifier.height(6.dp))
                Dim("Действия внутри других приложений Android не раскрывает: можно узнать только, какое приложение на экране и как долго. Поэтому такой анализ не реализован.", size = 12)
            }
        }
    }

    if (showPicker) {
        val apps by produceState<List<Pair<String, String>>>(emptyList()) {
            value = withContext(Dispatchers.Default) { Apps.launchable(ctx) }
        }
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Выберите приложение") },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(apps) { (pkg, name) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { pendingPkg = pkg; showPicker = false }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(pkg, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(name, maxLines = 1)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Закрыть") } }
        )
    }

    val pp = pendingPkg
    if (pp != null) {
        AlertDialog(
            onDismissRequest = { pendingPkg = null },
            title = { Text(Apps.label(ctx, pp)) },
            text = {
                Stepper("Лимит в день", "$pendingMin мин",
                    { pendingMin = (pendingMin - 15).coerceAtLeast(15) },
                    { pendingMin += 15 })
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.setLimit(pp, pendingMin); limits = prefs.limits(); pendingPkg = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { pendingPkg = null }) { Text("Отмена") } }
        )
    }

    if (confirm != 0) {
        val text = when (confirm) {
            1 -> "Вся сохранённая история использования и уведомлений будет удалена без возможности восстановления."
            2 -> "История будет очищена и собрана заново из того, что ещё хранит Android (обычно около 7 дней)."
            else -> "Сохранённая история счётчика уведомлений будет удалена."
        }
        AlertDialog(
            onDismissRequest = { confirm = 0 },
            title = { Text("Вы уверены?") },
            text = { Text(text) },
            confirmButton = {
                TextButton(onClick = {
                    when (confirm) {
                        1 -> vm.deleteHistory()
                        2 -> vm.resetStats()
                        else -> vm.deleteNotifs()
                    }
                    confirm = 0
                    toast(ctx, "Готово")
                }) { Text("Да") }
            },
            dismissButton = { TextButton(onClick = { confirm = 0 }) { Text("Отмена") } }
        )
    }
}
