package com.lifeos.ai.data

import android.content.Context
import androidx.room.*

/** kind: 0 = запуск, 1 = возвращение. confidence: 2 = есть начало и конец, 1 = оценка. */
@Entity(tableName = "sessions", indices = [Index("startMs"), Index("pkg")])
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pkg: String,
    val startMs: Long,
    val endMs: Long,
    val kind: Int,
    val confidence: Int
)

@Entity(tableName = "notifs", indices = [Index("timeMs")])
data class NotifEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pkg: String,
    val timeMs: Long
)

@Dao
interface LifeDao {
    @Query("SELECT * FROM sessions WHERE endMs > :from AND startMs < :to ORDER BY startMs")
    suspend fun sessions(from: Long, to: Long): List<SessionEntity>

    @Query("DELETE FROM sessions WHERE startMs >= :from")
    suspend fun deleteFrom(from: Long)

    @Insert
    suspend fun insertSessions(list: List<SessionEntity>)

    @Query("DELETE FROM sessions")
    suspend fun clearSessions()

    @Query("SELECT MIN(startMs) FROM sessions")
    suspend fun firstStart(): Long?

    @Insert
    suspend fun insertNotif(n: NotifEntity)

    @Query("SELECT * FROM notifs WHERE timeMs >= :from AND timeMs < :to")
    suspend fun notifs(from: Long, to: Long): List<NotifEntity>

    @Query("DELETE FROM notifs")
    suspend fun clearNotifs()
}

@Database(entities = [SessionEntity::class, NotifEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): LifeDao

    companion object {
        @Volatile
        private var inst: AppDb? = null

        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "lifeos.db")
                .build().also { inst = it }
        }
    }
}
