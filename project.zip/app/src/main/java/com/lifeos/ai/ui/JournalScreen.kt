package com.lifeos.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lifeos.ai.data.SessionEntity
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.stats.Stats
import com.lifeos.ai.usage.Apps
import java.time.Instant
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(vm: MainViewModel, onOpenApp: (String) -> Unit) {
    val ui by vm.ui.collectAsState()
    val jf by vm.jFilter.collectAsState()
    val js by vm.journal.collectAsState()
    val ctx = LocalContext.current
    var showPicker by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    if (!ui.hasPermission) {
        PermissionGate()
        return
    }

    val rows = ArrayList<Any>()
    var lastDay = -1L
    for (s in js.items) {
        val d = Stats.dayStart(s.startMs)
        if (d != lastDay) {
            rows.add(d)
            lastDay = d
        }
        rows.add(s)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Title("Журнал") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Сегодня", "Вчера", "7 дней", "30 дней").forEachIndexed { i, t ->
                    FilterChip(selected = jf.mode == i, onClick = { vm.setJournalMode(i) }, label = { Text(t) })
                }
                FilterChip(
                    selected = jf.mode == 4,
                    onClick = { showPicker = true },
                    label = { Text(if (jf.mode == 4 && jf.dateMs > 0) Fmt.date(jf.dateMs) else "Выбрать дату") }
                )
            }
        }
        item {
            Box {
                OutlinedButton(onClick = { menu = true }) {
                    Text(if (jf.pkg == null) "Все приложения" else Apps.label(ctx, jf.pkg!!), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Все приложения") }, onClick = { vm.setJournalApp(null); menu = false })
                    js.pkgs.forEach { p ->
                        DropdownMenuItem(text = { Text(Apps.label(ctx, p)) }, onClick = { vm.setJournalApp(p); menu = false })
                    }
                }
            }
        }
        item {
            Dim("Записи построены по событиям Android. Если система не передала событие, запись не создаётся и ничего не выдумывается.", size = 12)
        }
        if (rows.isEmpty()) {
            item {
                MessageCard("Нет событий", "За выбранный период и фильтр записей нет. Выберите другой период или обновите данные на главном экране.")
            }
        }
        items(rows.size) { i ->
            val r = rows[i]
            if (r is Long) {
                Text(Fmt.date(r), Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, color = Cyan)
            } else if (r is SessionEntity) {
                SessionCard(r) { onOpenApp(r.pkg) }
            }
        }
    }

    if (showPicker) {
        val st = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val ms = st.selectedDateMillis
                    if (ms != null) {
                        val ld = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        vm.setJournalDate(Stats.localDateStart(ld))
                    }
                    showPicker = false
                }) { Text("Показать") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Отмена") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
private fun SessionCard(s: SessionEntity, onClick: () -> Unit) {
    val ctx = LocalContext.current
    LCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(s.pkg, 36.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(Apps.label(ctx, s.pkg), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Dim("${Fmt.time(s.startMs)} — ${Fmt.time(s.endMs)} · предполагаемая сессия ${Fmt.dur(s.endMs - s.startMs)}")
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tag(if (s.kind == 0) "Запуск" else "Возвращение", Cyan)
            Tag(if (s.confidence == 2) "Достоверность: высокая" else "Достоверность: оценка", if (s.confidence == 2) Good else Danger)
        }
    }
}
