package com.lifeos.ai.usage

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.os.Build
import android.os.Process
import androidx.room.withTransaction
import com.lifeos.ai.data.AppDb
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.data.SessionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Названия приложений с кэшем. */
object Apps {
    private val labels = ConcurrentHashMap<String, String>()

    fun label(ctx: Context, pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    /** Установленные приложения, у которых есть значок запуска. */
    fun launchable(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != ctx.packageName }
            .map { it to label(ctx, it) }
            .sortedBy { it.second.lowercase() }
    }
}

class UsageCollector(private val ctx: Context) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private val db = AppDb.get(ctx)
    private val dao = db.dao()
    private val prefs = Prefs(ctx)

    companion object {
        private const val HOUR = 3_600_000L
        private const val DAY = 24 * HOUR
        /** Возврат в то же приложение быстрее этого времени считаем той же сессией. */
        private const val MERGE_GAP = 15_000L
        /** Если приложение было закрыто не более 5 минут назад — это «возвращение», а не новый запуск. */
        private const val RETURN_WINDOW = 5 * 60_000L

        private const val EV_RESUMED = 1
        private const val EV_PAUSED = 2
        private const val EV_SCREEN_OFF = 16
        private const val EV_SHUTDOWN = 26

        @Suppress("DEPRECATION")
        fun hasPermission(ctx: Context): Boolean {
            val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            } else {
                ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private class Open(val pkg: String, val start: Long, val kind: Int) {
        var pausedAt = 0L
    }

    private fun ignoredPackages(): Set<String> {
        val s = mutableSetOf(ctx.packageName, "com.android.systemui", "android", "com.miui.home")
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { s.add(it) }
        return s
    }

    /** Читает события Android и сохраняет сессии. Возвращает количество найденных сессий. */
    suspend fun sync(): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val now = System.currentTimeMillis()
            val last = prefs.lastSync
            val from = if (last == 0L) now - 7 * DAY else maxOf(last - 3 * HOUR, now - 9 * DAY)
            val list = build(from, now)
            db.withTransaction {
                dao.deleteFrom(from)
                dao.insertSessions(list)
            }
            prefs.lastSync = now
            list.size
        }
    }

    private fun build(from: Long, to: Long): List<SessionEntity> {
        val ignored = ignoredPackages()
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        val out = ArrayList<SessionEntity>()
        val lastEnd = HashMap<String, Long>()
        var cur: Open? = null

        fun finish(at: Long) {
            val c = cur ?: return
            val end = if (c.pausedAt > 0L) c.pausedAt else at
            val conf = if (c.pausedAt > 0L) 2 else 1
            if (end > c.start) {
                out.add(SessionEntity(pkg = c.pkg, startMs = c.start, endMs = end, kind = c.kind, confidence = conf))
                lastEnd[c.pkg] = end
            }
            cur = null
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val t = e.timeStamp
            val p = e.packageName ?: continue
            when (e.eventType) {
                EV_RESUMED -> {
                    if (p in ignored) {
                        finish(t)
                    } else {
                        val c = cur
                        if (c != null && c.pkg == p && (c.pausedAt == 0L || t - c.pausedAt <= MERGE_GAP)) {
                            c.pausedAt = 0L
                        } else {
                            finish(t)
                            val prev = lastEnd[p]
                            val kind = if (prev != null && t - prev <= RETURN_WINDOW) 1 else 0
                            cur = Open(p, t, kind)
                        }
                    }
                }
                EV_PAUSED -> {
                    val c = cur
                    if (c != null && c.pkg == p) c.pausedAt = t
                }
                EV_SCREEN_OFF, EV_SHUTDOWN -> finish(t)
            }
        }
        finish(to)
        return out
    }
}
