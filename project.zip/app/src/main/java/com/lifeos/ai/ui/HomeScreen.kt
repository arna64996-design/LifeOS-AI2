package com.lifeos.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.usage.Apps

@Composable
fun HomeScreen(vm: MainViewModel, onOpenApp: (String) -> Unit) {
    val ui by vm.ui.collectAsState()
    val ctx = LocalContext.current
    if (!ui.hasPermission) {
        PermissionGate()
        return
    }
    val today = ui.today
    val err = ui.error

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Title("LifeOS AI")
                    Dim(if (ui.lastSync > 0) "Обновлено в ${Fmt.time(ui.lastSync)}" else "Ещё не обновлялось")
                }
                if (ui.loading) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Cyan)
                } else {
                    IconButton(onClick = { vm.refresh() }) { Icon(Icons.Default.Refresh, contentDescription = "Обновить") }
                }
            }
        }
        if (err != null) {
            item { MessageCard("Ошибка получения статистики", err, "Повторить") { vm.refresh() } }
        }
        if (today == null) {
            if (err == null) item { LoadingCard() }
        } else {
            val y = ui.yesterday
            val w = ui.last7

            item {
                LCard {
                    Dim("Экранное время сегодня")
                    Spacer(Modifier.height(4.dp))
                    Text(Fmt.dur(today.totalMs), fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    ChangeText(if (y != null) Fmt.pct(today.totalMs, y.totalMs) else null, "к этому же времени вчера")
                }
            }
            if (today.sessions == 0) {
                item {
                    MessageCard(
                        "Пока нет данных за сегодня",
                        "Android ещё не передал события использования за сегодня. Пользуйтесь телефоном и нажмите «обновить». Если данных нет долго, проверьте доступ в Настройках."
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    StatTile("Запуски", today.launches.toString(), Modifier.weight(1f), "обнаружено")
                    StatTile("Сессии", today.sessions.toString(), Modifier.weight(1f), "предполагаемые")
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    val t = today.topByTime
                    val l = today.topByLaunches
                    TopApp("Больше всего времени", t?.pkg, t?.let { Fmt.dur(it.totalMs) }, Modifier.weight(1f), onOpenApp)
                    TopApp("Чаще запускается", l?.pkg, l?.let { "${it.launches} раз" }, Modifier.weight(1f), onOpenApp)
                }
            }
            item {
                LCard {
                    CardTitle("Использование по часам")
                    Dim("Минуты по часам суток, сегодня")
                    Spacer(Modifier.height(12.dp))
                    BarChart(today.hourly.map { Fmt.minutes(it) }, Fmt.hourLabels())
                }
            }
            if (w != null) {
                item {
                    LCard {
                        CardTitle("7 дней")
                        Spacer(Modifier.height(12.dp))
                        BarChart(w.daily.map { Fmt.minutes(it.totalMs) }, Fmt.dayLabels(w.daily, true))
                        if (ui.historyDays < 2) {
                            Spacer(Modifier.height(8.dp))
                            Dim("Недостаточно истории для сравнения: накоплено дней — ${ui.historyDays}. Графики заполнятся по мере использования.")
                        }
                    }
                }
            }
            if (today.apps.isNotEmpty()) {
                item {
                    LCard {
                        CardTitle("Распределение времени")
                        Spacer(Modifier.height(4.dp))
                        val max = today.apps.first().totalMs.coerceAtLeast(1L)
                        today.apps.take(6).forEach { a ->
                            AppRow(
                                a.pkg, Apps.label(ctx, a.pkg),
                                "${a.launches} запусков · ${a.sessions} сессий",
                                Fmt.dur(a.totalMs), a.totalMs.toFloat() / max
                            ) { onOpenApp(a.pkg) }
                        }
                    }
                }
            }
            item {
                Dim(
                    "Запуски и сессии — оценка по событиям Android, а не точный счётчик: система может не передавать часть событий, а режим энергосбережения Xiaomi/POCO иногда их теряет.",
                    size = 12
                )
            }
        }
    }
}

@Composable
private fun TopApp(label: String, pkg: String?, value: String?, modifier: Modifier, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    Column(
        modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
            .background(CardBg)
            .let { if (pkg != null) it.clickable { onOpen(pkg) } else it }
            .padding(16.dp)
    ) {
        Dim(label)
        Spacer(Modifier.height(8.dp))
        if (pkg == null) {
            Text("—", fontSize = 18.sp)
        } else {
            AppIcon(pkg, 36.dp)
            Spacer(Modifier.height(6.dp))
            Text(Apps.label(ctx, pkg), maxLines = 1, fontWeight = FontWeight.SemiBold, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Dim(value ?: "")
        }
    }
}
