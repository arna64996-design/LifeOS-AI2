package com.lifeos.ai.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.lifeos.ai.data.AppDb
import com.lifeos.ai.data.Prefs
import com.lifeos.ai.stats.Fmt
import com.lifeos.ai.stats.PeriodStats
import com.lifeos.ai.stats.Stats
import com.lifeos.ai.usage.Apps
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMsg(val role: String, val text: String)

class AiException(message: String) : Exception(message)

/** Любой провайдер: получает системную инструкцию и историю чата, возвращает текст ответа. */
interface AiProvider {
    fun ask(system: String, history: List<ChatMsg>): String
}

private fun post(url: String, headers: Map<String, String>, body: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
        c.requestMethod = "POST"
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw AiException("Ошибка сервера ИИ ($code): ${text.take(300)}")
        return text
    } finally {
        c.disconnect()
    }
}

/** OpenAI и совместимые сервисы (/chat/completions). */
class OpenAiCompatible(private val baseUrl: String, private val key: String, private val model: String) : AiProvider {
    override fun ask(system: String, history: List<ChatMsg>): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val res = JSONObject(post("${baseUrl.trimEnd('/')}/chat/completions", mapOf("Authorization" to "Bearer $key"), body))
        return res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}

/** Anthropic Messages API. */
class AnthropicProvider(private val baseUrl: String, private val key: String, private val model: String) : AiProvider {
    override fun ask(system: String, history: List<ChatMsg>): String {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("max_tokens", 1024)
            .put("system", system).put("messages", msgs).toString()
        val res = JSONObject(
            post(
                "${baseUrl.trimEnd('/')}/messages",
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body
            )
        )
        val arr = res.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString()
    }
}

object AiService {
    fun configured(p: Prefs): Boolean =
        p.aiConsent && p.aiKey.isNotBlank() && p.aiModel.isNotBlank() && p.aiUrl.isNotBlank()

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun provider(p: Prefs): AiProvider =
        if (p.aiProvider == "anthropic") AnthropicProvider(p.aiUrl, p.aiKey, p.aiModel)
        else OpenAiCompatible(p.aiUrl, p.aiKey, p.aiModel)

    suspend fun ask(ctx: Context, history: List<ChatMsg>): String {
        val prefs = Prefs(ctx)
        if (!configured(prefs)) throw AiException("ИИ не настроен: откройте Настройки → ИИ-помощник.")
        if (!online(ctx)) throw AiException("Нет подключения к интернету.")
        val system = "Ты — ИИ-помощник приложения LifeOS AI. Отвечай по-русски, коротко и по делу. " +
            "Используй ТОЛЬКО статистику ниже. Не выдумывай числа, приложения и привычки, которых нет в данных. " +
            "Если данных недостаточно для ответа — прямо скажи об этом. " +
            "Помни: «запуски» и «сессии» — оценка по событиям Android, а не точный счётчик. " +
            "Давай практичные советы без морализаторства.\n\n" + buildContext(ctx)
        return provider(prefs).ask(system, history)
    }

    suspend fun buildContext(ctx: Context): String {
        val dao = AppDb.get(ctx).dao()
        val now = System.currentTimeMillis()
        val ds = Stats.dayStart(now)
        val de = Stats.addDays(ds, 1)
        val all = dao.sessions(Stats.addDays(ds, -13), de)
        val today = Stats.compute(all, ds, de)
        val yest = Stats.compute(all, Stats.addDays(ds, -1), Stats.addDays(now, -1))
        val w = Stats.compute(all, Stats.addDays(ds, -6), de)
        val p = Stats.compute(all, Stats.addDays(ds, -13), Stats.addDays(ds, -6))
        val first = dao.firstStart()
        val days = if (first == null) 0 else ((now - Stats.dayStart(first)) / 86_400_000L).toInt() + 1

        fun apps(s: PeriodStats, n: Int) = s.apps.take(n).mapIndexed { i, a ->
            "${i + 1}. ${Apps.label(ctx, a.pkg)} — ${Fmt.dur(a.totalMs)}, обнаруженных запусков ${a.launches}, сессий ${a.sessions}"
        }.ifEmpty { listOf("нет данных") }.joinToString("\n")

        val sb = StringBuilder()
        sb.append("СТАТИСТИКА (накоплено дней истории: $days)\n")
        sb.append("Сейчас: ${Fmt.dateTime(now)}\n\n")
        sb.append("СЕГОДНЯ: всего ${Fmt.dur(today.totalMs)}, запусков ${today.launches}, возвращений ${today.returns}, сессий ${today.sessions}\n")
        sb.append(apps(today, 8)).append("\n\n")
        sb.append("ВЧЕРА К ЭТОМУ ЖЕ ВРЕМЕНИ: всего ${Fmt.dur(yest.totalMs)}, запусков ${yest.launches}\n\n")
        sb.append("ПОСЛЕДНИЕ 7 ДНЕЙ: всего ${Fmt.dur(w.totalMs)}\nПо дням: ")
        sb.append(w.daily.joinToString("; ") { "${Fmt.date(it.dayStart)} — ${Fmt.dur(it.totalMs)}" }).append("\n")
        sb.append(apps(w, 10)).append("\n\n")
        sb.append("ПРЕДЫДУЩИЕ 7 ДНЕЙ (для сравнения): всего ${Fmt.dur(p.totalMs)}\n")
        sb.append(apps(p, 10)).append("\n\n")
        val peak = w.hourly.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }.take(3)
        sb.append("АКТИВНЫЕ ЧАСЫ (7 дней): ")
        sb.append(if (peak.isEmpty()) "нет данных" else peak.joinToString("; ") { "%02d:00 — %s".format(it.index, Fmt.dur(it.value)) })
        sb.append("\n")
        if (Prefs(ctx).collectNotifs) {
            val n = dao.notifs(ds, de)
            sb.append("\nУВЕДОМЛЕНИЯ СЕГОДНЯ: всего ${n.size}; ")
            sb.append(n.groupBy { it.pkg }.map { it.key to it.value.size }.sortedByDescending { it.second }.take(5)
                .joinToString("; ") { "${Apps.label(ctx, it.first)} — ${it.second}" })
        }
        return sb.toString()
    }
}

/** Обычные правила без нейросети. В интерфейсе подписаны честно: «без ИИ». */
object LocalInsights {
    fun generate(ctx: Context, today: PeriodStats, week: PeriodStats, prev: PeriodStats, historyDays: Int): List<String> {
        if (week.sessions == 0) {
            return listOf("Пока нет собранных данных. Пользуйтесь телефоном как обычно и обновите статистику позже.")
        }
        val out = mutableListOf<String>()
        today.topByTime?.let {
            val share = if (today.totalMs > 0) it.totalMs * 100 / today.totalMs else 0
            out.add("Сегодня больше всего времени ушло на «${Apps.label(ctx, it.pkg)}»: ${Fmt.dur(it.totalMs)} ($share% экранного времени).")
        }
        today.topByLaunches?.let {
            if (it.launches >= 3) out.add("Чаще всего сегодня запускалось «${Apps.label(ctx, it.pkg)}»: ${it.launches} обнаруженных запусков.")
        }
        val peak = week.hourly.withIndex().maxByOrNull { it.value }
        if (peak != null && peak.value > 0) {
            out.add("За 7 дней вы активнее всего около %02d:00 (суммарно %s).".format(peak.index, Fmt.dur(peak.value)))
        }
        if (prev.sessions > 0) {
            val grown = week.apps.mapNotNull { a ->
                val before = prev.apps.firstOrNull { it.pkg == a.pkg }?.totalMs ?: return@mapNotNull null
                val pct = Fmt.pct(a.totalMs, before) ?: return@mapNotNull null
                if (pct >= 30 && a.totalMs - before >= 20 * 60_000L) Triple(a.pkg, pct, a.totalMs - before) else null
            }.sortedByDescending { it.third }.take(3)
            grown.forEach { out.add("«${Apps.label(ctx, it.first)}» занимает больше времени, чем неделей ранее: ${Fmt.signed(it.second)}.") }
            Fmt.pct(week.totalMs, prev.totalMs)?.let { out.add("Общее экранное время за 7 дней: ${Fmt.signed(it)} к предыдущим 7 дням.") }
        }
        if (historyDays < 7) out.add("Накоплено только $historyDays дн. истории — выводы приблизительные.")
        return out
    }
}
